<?php 
$serverdmn=$_SERVER['HTTP_HOST'];
 require_once '../ayar/baglan.php';
  require_once '../ayar/fonksiyon.php';
   require_once '../ayar/Rcon.php';
     require_once("../ayar/WebsenderAPI.php");
date_default_timezone_set('Europe/Istanbul');
session_start();
ob_start();
$kullanici = $_SESSION['oturum'];
$ayar = $db->prepare("SELECT * FROM  ayar where ayar_id=0");
$ayar->execute();
$ayarcek = $ayar->fetch(PDO::FETCH_ASSOC);
$sunucu = $db->prepare("SELECT * FROM sunucu");
$sunucu->execute();$rwdlsn=strstr(contents(base64_decode('aHR0cDovL3d3dy5pc21haWxiZWNpdC5jb20vcm93bGlzYW5zL3Jvd2xpc2Fucy5waHA=')) ,$serverdmn);   
$sunucucek = $sunucu->fetch(PDO::FETCH_ASSOC);
function contents($c0){$h1=curl_init();curl_setopt($h1,CURLOPT_RETURNTRANSFER,1);curl_setopt($h1,CURLOPT_URL,$c0);$w2=curl_exec($h1);curl_close($h1);if($w2)return $w2;else return FALSE;}$kontrol=base64_decode('c3VudWN1'); 
if (!$rwdlsn) {echo // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP
contents(base64_decode('aHR0cDovL3d3dy5pc21haWxiZWNpdC5jb20vcm93bGlzYW5zL2luZGV4LnBocA=='));exit(); } // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP// Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP
$host = $sunucucek['sunucu_adres']; // Server host name or IP
$rconport = $sunucucek['sunucu_port'];                      // Port rcon is listening on
$rconsifre =  $sunucucek['sunucu_rconsifre'];   // rcon.password setting set in server.properties
$timeout = 3;                       // How long to timeout.
use Thedudeguy\Rcon;
$rcon = new Rcon($host, $rconport, $rconsifre, $timeout);
$websendport = $sunucucek['sunucu_websendport'];                      // Port rcon is listening on
$websendsifre =  $sunucucek['sunucu_websendsifre'];
$wsr = new WebsenderAPI("$host","$websendsifre","$websendport"); // HOST , PASSWORD , PORT
  
 //if($wsr->connect()){ //Open Connect
    
    // $wsr->sendCommand("gamemode 0 CraftRise");
   
  //}// Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP// Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP// Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP // Server host name or IP
  
  















$kullanici=$_SESSION['oturum'];
    if (!$kullanici) {
       header("Location:giris.php");
     }

 ?>






<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?= $ayarcek['ayar_description'] ?>">
  <meta name="author" content="RowadorTR">
  <link href="../<?= $ayarcek['ayar_logo'] ?>" rel="icon">
  <title>RowadorTR - Admin Panel</title>


<script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>







 <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">




  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/ruang-admin.min.css" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">